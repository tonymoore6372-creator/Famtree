package com.familytree.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RelationshipDao {

    @Query("SELECT * FROM relationships")
    fun observeAll(): Flow<List<Relationship>>

    @Query("SELECT * FROM relationships")
    suspend fun getAllOnce(): List<Relationship>

    @Query("""
        SELECT * FROM relationships
        WHERE (personId = :personId OR relatedPersonId = :personId)
    """)
    suspend fun getForPerson(personId: String): List<Relationship>

    @Query("SELECT * FROM relationships WHERE relatedPersonId = :personId AND type = 'PARENT_OF'")
    suspend fun getParentsOf(personId: String): List<Relationship>

    @Query("SELECT * FROM relationships WHERE personId = :personId AND type = 'PARENT_OF'")
    suspend fun getChildrenOf(personId: String): List<Relationship>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(relationship: Relationship)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(relationships: List<Relationship>)

    @Delete
    suspend fun delete(relationship: Relationship)
}
