package com.familytree.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.familytree.app.data.Person
import com.familytree.app.ui.TreeViewModel

@Composable
fun AddPersonScreen(viewModel: TreeViewModel, deviceId: String, onSaved: () -> Unit) {
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var birthDate by remember { mutableStateOf("") }
    var birthPlace by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf<String?>(null) }

    var linkAsChildOf by remember { mutableStateOf<Person?>(null) }
    val people by viewModel.people.collectAsState()
    var showPicker by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Add a family member", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(value = firstName, onValueChange = { firstName = it }, label = { Text("First name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = lastName, onValueChange = { lastName = it }, label = { Text("Last name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = birthDate, onValueChange = { birthDate = it }, label = { Text("Birth date (e.g. 1965 or 1965-04-12)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = birthPlace, onValueChange = { birthPlace = it }, label = { Text("Birth place") }, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(8.dp))
        Row {
            listOf("male", "female", "other").forEach { option ->
                FilterChip(
                    selected = gender == option,
                    onClick = { gender = if (gender == option) null else option },
                    label = { Text(option) },
                    modifier = Modifier.padding(end = 8.dp)
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        if (people.isNotEmpty()) {
            OutlinedButton(onClick = { showPicker = true }) {
                Text(linkAsChildOf?.let { "Child of: ${it.firstName} ${it.lastName}" } ?: "Link as child of… (optional)")
            }
        }

        if (showPicker) {
            AlertDialog(
                onDismissRequest = { showPicker = false },
                confirmButton = {},
                title = { Text("Select parent") },
                text = {
                    Column {
                        people.forEach { p ->
                            TextButton(onClick = {
                                linkAsChildOf = p
                                showPicker = false
                            }) {
                                Text("${p.firstName} ${p.lastName}")
                            }
                        }
                    }
                }
            )
        }

        Spacer(Modifier.height(24.dp))
        Button(
            onClick = {
                if (firstName.isNotBlank() && lastName.isNotBlank()) {
                    viewModel.addPerson(
                        firstName = firstName.trim(),
                        lastName = lastName.trim(),
                        gender = gender,
                        birthDate = birthDate.ifBlank { null },
                        birthPlace = birthPlace.ifBlank { null },
                        deviceId = deviceId,
                        parentId = linkAsChildOf?.id
                    )
                    onSaved()
                }
            },
            enabled = firstName.isNotBlank() && lastName.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Save")
        }
    }
}
