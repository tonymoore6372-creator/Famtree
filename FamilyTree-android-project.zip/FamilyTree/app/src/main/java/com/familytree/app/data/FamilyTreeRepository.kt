package com.familytree.app.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

class FamilyTreeRepository(
    private val personDao: PersonDao,
    private val relationshipDao: RelationshipDao
) {
    fun observePersons(): Flow<List<Person>> = personDao.observeAll()
    fun observeRelationships(): Flow<List<Relationship>> = relationshipDao.observeAll()

    fun observeTree(): Flow<FamilyTreeSnapshot> =
        combine(observePersons(), observeRelationships()) { people, rels ->
            FamilyTreeSnapshot(people, rels)
        }

    suspend fun addPerson(person: Person) = personDao.insert(person)

    suspend fun updatePerson(person: Person) =
        personDao.update(person.copy(updatedAt = System.currentTimeMillis()))

    suspend fun deletePerson(person: Person) = personDao.delete(person)

    suspend fun addRelationship(relationship: Relationship) = relationshipDao.insert(relationship)

    suspend fun linkParentChild(parentId: String, childId: String) {
        relationshipDao.insert(
            Relationship(personId = parentId, relatedPersonId = childId, type = RelationType.PARENT_OF)
        )
    }

    suspend fun linkSpouses(personAId: String, personBId: String) {
        relationshipDao.insert(
            Relationship(personId = personAId, relatedPersonId = personBId, type = RelationType.SPOUSE_OF)
        )
    }

    /** Full local snapshot, used to build the payload sent over Bluetooth. */
    suspend fun exportSnapshot(): FamilyTreeSnapshot =
        FamilyTreeSnapshot(personDao.getAllOnce(), relationshipDao.getAllOnce())

    /**
     * Merge an incoming snapshot (received from a relative's device) into the
     * local database. Strategy: last-write-wins on `updatedAt`, matched by
     * the record's UUID. New records (unseen UUIDs) are inserted as-is.
     * Returns counts so the UI can show "12 people added, 3 updated".
     */
    suspend fun mergeSnapshot(incoming: FamilyTreeSnapshot): MergeResult {
        val existingPeople = personDao.getAllOnce().associateBy { it.id }
        var peopleAdded = 0
        var peopleUpdated = 0

        val peopleToWrite = incoming.people.mapNotNull { incomingPerson ->
            val existing = existingPeople[incomingPerson.id]
            when {
                existing == null -> { peopleAdded++; incomingPerson }
                incomingPerson.updatedAt > existing.updatedAt -> { peopleUpdated++; incomingPerson }
                else -> null // local copy is newer or same; keep it
            }
        }
        if (peopleToWrite.isNotEmpty()) personDao.insertAll(peopleToWrite)

        val existingRels = relationshipDao.getAllOnce().associateBy { it.id }
        var relsAdded = 0
        val relsToWrite = incoming.relationships.mapNotNull { incomingRel ->
            val existing = existingRels[incomingRel.id]
            when {
                existing == null -> { relsAdded++; incomingRel }
                incomingRel.updatedAt > existing.updatedAt -> incomingRel
                else -> null
            }
        }
        if (relsToWrite.isNotEmpty()) relationshipDao.insertAll(relsToWrite)

        return MergeResult(peopleAdded, peopleUpdated, relsAdded)
    }
}

data class FamilyTreeSnapshot(
    val people: List<Person>,
    val relationships: List<Relationship>
)

data class MergeResult(
    val peopleAdded: Int,
    val peopleUpdated: Int,
    val relationshipsAdded: Int
)
