package com.familytree.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.familytree.app.data.Person
import com.familytree.app.ui.TreeViewModel

@Composable
fun FamilyTreeScreen(viewModel: TreeViewModel) {
    val people by viewModel.people.collectAsState()
    var expandedPersonId by remember { mutableStateOf<String?>(null) }

    if (people.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
            Text("No one in your tree yet. Tap \"Add Person\" to get started.")
        }
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        items(people, key = { it.id }) { person ->
            PersonCard(
                person = person,
                expanded = expandedPersonId == person.id,
                onToggle = {
                    expandedPersonId = if (expandedPersonId == person.id) null else person.id
                },
                parents = if (expandedPersonId == person.id) viewModel.parentsOf(person.id) else emptyList(),
                children = if (expandedPersonId == person.id) viewModel.childrenOf(person.id) else emptyList()
            )
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun PersonCard(
    person: Person,
    expanded: Boolean,
    onToggle: () -> Unit,
    parents: List<Person>,
    children: List<Person>
) {
    Card(modifier = Modifier.fillMaxWidth().clickable { onToggle() }) {
        Column(Modifier.padding(12.dp)) {
            Text("${person.firstName} ${person.lastName}", style = MaterialTheme.typography.titleMedium)
            val lifespan = listOfNotNull(person.birthDate, person.deathDate.takeIf { !person.isLiving })
                .joinToString(" – ")
            if (lifespan.isNotBlank()) {
                Text(lifespan, style = MaterialTheme.typography.bodySmall)
            }
            person.birthPlace?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

            if (expanded) {
                Spacer(Modifier.height(8.dp))
                if (parents.isNotEmpty()) {
                    Text("Parents", style = MaterialTheme.typography.labelMedium)
                    parents.forEach { Text("• ${it.firstName} ${it.lastName}") }
                }
                if (children.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text("Children", style = MaterialTheme.typography.labelMedium)
                    children.forEach { Text("• ${it.firstName} ${it.lastName}") }
                }
                if (parents.isEmpty() && children.isEmpty()) {
                    Text("No relationships linked yet.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
