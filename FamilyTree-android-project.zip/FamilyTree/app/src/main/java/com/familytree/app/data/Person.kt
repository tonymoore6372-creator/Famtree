package com.familytree.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * A single person in the family tree.
 *
 * The primary key is a UUID (not an autoincrement Int) on purpose: when two
 * relatives sync their trees over Bluetooth, each device has been creating
 * records independently and offline. UUIDs let both sides merge records
 * without ever colliding on IDs.
 */
@Entity(tableName = "persons")
@Serializable
data class Person(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val firstName: String,
    val lastName: String,
    val gender: String? = null,              // "male", "female", "other", null = unspecified
    val birthDate: String? = null,            // ISO-8601 "yyyy-MM-dd", may be partial e.g. "1930"
    val deathDate: String? = null,
    val birthPlace: String? = null,
    val notes: String? = null,
    val photoUri: String? = null,
    val isLiving: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val originDeviceId: String = ""           // which device first created this record
)
