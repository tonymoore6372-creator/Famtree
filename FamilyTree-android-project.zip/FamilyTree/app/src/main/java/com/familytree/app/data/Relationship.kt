package com.familytree.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable
import java.util.UUID

enum class RelationType {
    PARENT_OF,   // personId is the parent of relatedPersonId
    SPOUSE_OF,   // symmetric union, stored once
    SIBLING_OF   // symmetric, stored once (optional, can also be derived from shared parents)
}

/**
 * A directed or symmetric edge between two Persons.
 * Kept as its own table (rather than parentId columns on Person) so a person
 * can have multiple parents/spouses over time without schema changes.
 */
@Entity(
    tableName = "relationships",
    foreignKeys = [
        ForeignKey(entity = Person::class, parentColumns = ["id"], childColumns = ["personId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = Person::class, parentColumns = ["id"], childColumns = ["relatedPersonId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("personId"), Index("relatedPersonId")]
)
@Serializable
data class Relationship(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val personId: String,
    val relatedPersonId: String,
    val type: RelationType,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
