package com.familytree.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

class Converters {
    @TypeConverter
    fun fromRelationType(type: RelationType): String = type.name

    @TypeConverter
    fun toRelationType(value: String): RelationType = RelationType.valueOf(value)
}

@Database(
    entities = [Person::class, Relationship::class],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class FamilyTreeDatabase : RoomDatabase() {

    abstract fun personDao(): PersonDao
    abstract fun relationshipDao(): RelationshipDao

    companion object {
        @Volatile private var INSTANCE: FamilyTreeDatabase? = null

        fun getInstance(context: Context): FamilyTreeDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    FamilyTreeDatabase::class.java,
                    "family_tree.db"
                )
                    // Offline-first local DB; safe default while the schema is young.
                    // Replace with real Migration objects before shipping v2+.
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
