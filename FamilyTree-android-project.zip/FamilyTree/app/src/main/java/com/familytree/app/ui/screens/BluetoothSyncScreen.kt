package com.familytree.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.familytree.app.bluetooth.SyncState
import com.familytree.app.ui.TreeViewModel

@Composable
fun BluetoothSyncScreen(viewModel: TreeViewModel) {
    val syncState by viewModel.syncState.collectAsState()
    val devices = remember { viewModel.pairedDevices() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Sync with a relative", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(4.dp))
        Text(
            "Both phones need Bluetooth on and already paired with each other. " +
                "One person taps \"Wait for connection\", the other picks that device below.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(16.dp))

        when (val state = syncState) {
            is SyncState.Idle -> {
                Button(onClick = { viewModel.startHosting() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Wait for connection")
                }
                Spacer(Modifier.height(16.dp))
                Text("Or connect to a paired device:", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(8.dp))
                if (devices.isEmpty()) {
                    Text("No paired Bluetooth devices found. Pair with your relative's phone in Android Bluetooth settings first.")
                } else {
                    LazyColumn {
                        items(devices) { device ->
                            @Suppress("MissingPermission")
                            ListItem(
                                headlineContent = { Text(device.name ?: device.address) },
                                supportingContent = { Text(device.address) },
                                modifier = Modifier.clickable { viewModel.connectToDevice(device) }
                            )
                            Divider()
                        }
                    }
                }
            }
            is SyncState.Listening -> StatusCard("Waiting for your relative to connect…")
            is SyncState.Connecting -> StatusCard("Connecting…")
            is SyncState.Connected -> StatusCard("Connected. Exchanging family tree data…")
            is SyncState.Exchanging -> StatusCard("Exchanging family tree data…")
            is SyncState.Success -> {
                StatusCard(
                    "Sync complete!\n" +
                        "${state.peopleAdded} people added, ${state.peopleUpdated} updated, " +
                        "${state.relationshipsAdded} relationships added."
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = { viewModel.cancelSync() }) { Text("Done") }
            }
            is SyncState.Error -> {
                StatusCard("Something went wrong: ${state.message}")
                Spacer(Modifier.height(12.dp))
                Button(onClick = { viewModel.cancelSync() }) { Text("Try again") }
            }
        }
    }
}

@Composable
private fun StatusCard(message: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Text(message, modifier = Modifier.padding(16.dp))
    }
}
