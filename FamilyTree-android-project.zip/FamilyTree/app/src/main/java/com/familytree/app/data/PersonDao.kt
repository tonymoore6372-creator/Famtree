package com.familytree.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PersonDao {

    @Query("SELECT * FROM persons ORDER BY lastName, firstName")
    fun observeAll(): Flow<List<Person>>

    @Query("SELECT * FROM persons WHERE id = :id")
    suspend fun getById(id: String): Person?

    @Query("SELECT * FROM persons")
    suspend fun getAllOnce(): List<Person>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(person: Person)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(people: List<Person>)

    @Update
    suspend fun update(person: Person)

    @Delete
    suspend fun delete(person: Person)

    @Query("SELECT * FROM persons WHERE firstName LIKE '%' || :query || '%' OR lastName LIKE '%' || :query || '%'")
    suspend fun search(query: String): List<Person>
}
