package com.familytree.app.ui

import android.bluetooth.BluetoothDevice
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.familytree.app.bluetooth.BluetoothSyncManager
import com.familytree.app.bluetooth.SyncPayload
import com.familytree.app.bluetooth.SyncState
import com.familytree.app.data.FamilyTreeRepository
import com.familytree.app.data.Person
import com.familytree.app.data.RelationType
import com.familytree.app.data.Relationship
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class TreeViewModel(
    private val repository: FamilyTreeRepository,
    private val bluetoothSyncManager: BluetoothSyncManager
) : ViewModel() {

    private val _people = MutableStateFlow<List<Person>>(emptyList())
    val people: StateFlow<List<Person>> = _people.asStateFlow()

    private val _relationships = MutableStateFlow<List<Relationship>>(emptyList())
    val relationships: StateFlow<List<Relationship>> = _relationships.asStateFlow()

    val syncState: StateFlow<SyncState> = bluetoothSyncManager.state

    init {
        viewModelScope.launch {
            repository.observePersons().collect { _people.value = it }
        }
        viewModelScope.launch {
            repository.observeRelationships().collect { _relationships.value = it }
        }
    }

    fun addPerson(
        firstName: String,
        lastName: String,
        gender: String?,
        birthDate: String?,
        birthPlace: String?,
        deviceId: String,
        parentId: String? = null
    ) {
        viewModelScope.launch {
            val newPerson = Person(
                firstName = firstName,
                lastName = lastName,
                gender = gender,
                birthDate = birthDate,
                birthPlace = birthPlace,
                originDeviceId = deviceId
            )
            repository.addPerson(newPerson)
            if (parentId != null) {
                repository.linkParentChild(parentId, newPerson.id)
            }
        }
    }

    fun linkParentChild(parentId: String, childId: String) {
        viewModelScope.launch { repository.linkParentChild(parentId, childId) }
    }

    fun linkSpouses(personAId: String, personBId: String) {
        viewModelScope.launch { repository.linkSpouses(personAId, personBId) }
    }

    fun parentsOf(personId: String): List<Person> {
        val parentIds = relationships.value
            .filter { it.type == RelationType.PARENT_OF && it.relatedPersonId == personId }
            .map { it.personId }
        return people.value.filter { it.id in parentIds }
    }

    fun childrenOf(personId: String): List<Person> {
        val childIds = relationships.value
            .filter { it.type == RelationType.PARENT_OF && it.personId == personId }
            .map { it.relatedPersonId }
        return people.value.filter { it.id in childIds }
    }

    // --- Bluetooth sync ---

    fun pairedDevices(): List<BluetoothDevice> = bluetoothSyncManager.pairedDevices()

    fun startHosting() = bluetoothSyncManager.startHosting()

    fun connectToDevice(device: BluetoothDevice) = bluetoothSyncManager.connectToDevice(device)

    fun cancelSync() = bluetoothSyncManager.reset()
}

/** Wires the repository into the callbacks the BluetoothSyncManager needs, without the manager depending on Room directly. */
fun buildBluetoothSyncManager(
    context: android.content.Context,
    deviceId: String,
    repository: FamilyTreeRepository
): BluetoothSyncManager = BluetoothSyncManager(
    context = context,
    deviceId = deviceId,
    buildLocalPayload = {
        val snapshot = repository.exportSnapshot()
        SyncPayload(deviceId, snapshot.people, snapshot.relationships)
    },
    onPayloadReceived = { payload ->
        repository.mergeSnapshot(
            com.familytree.app.data.FamilyTreeSnapshot(payload.people, payload.relationships)
        )
    }
)
