package com.familytree.app.ui

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import com.familytree.app.FamilyTreeApp
import com.familytree.app.ui.screens.AddPersonScreen
import com.familytree.app.ui.screens.BluetoothSyncScreen
import com.familytree.app.ui.screens.FamilyTreeScreen

enum class Screen { TREE, ADD_PERSON, SYNC }

class MainActivity : ComponentActivity() {

    private val viewModel: TreeViewModel by viewModels {
        object : ViewModelProvider.Factory {
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T {
                val app = application as FamilyTreeApp
                val btManager = buildBluetoothSyncManager(applicationContext, app.deviceId, app.repository)
                @Suppress("UNCHECKED_CAST")
                return TreeViewModel(app.repository, btManager) as T
            }
        }
    }

    private val requestBtPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* result handled implicitly; user can retry sync if denied */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_ADVERTISE
            )
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        requestBtPermissions.launch(permissions)

        setContent {
            MaterialTheme {
                var screen by remember { mutableStateOf(Screen.TREE) }
                val deviceId = (application as FamilyTreeApp).deviceId

                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(
                                selected = screen == Screen.TREE,
                                onClick = { screen = Screen.TREE },
                                label = { Text("Tree") },
                                icon = {}
                            )
                            NavigationBarItem(
                                selected = screen == Screen.ADD_PERSON,
                                onClick = { screen = Screen.ADD_PERSON },
                                label = { Text("Add Person") },
                                icon = {}
                            )
                            NavigationBarItem(
                                selected = screen == Screen.SYNC,
                                onClick = { screen = Screen.SYNC },
                                label = { Text("Sync") },
                                icon = {}
                            )
                        }
                    }
                ) { padding ->
                    Box(modifier = Modifier.padding(padding)) {
                        when (screen) {
                            Screen.TREE -> FamilyTreeScreen(viewModel)
                            Screen.ADD_PERSON -> AddPersonScreen(viewModel, deviceId) { screen = Screen.TREE }
                            Screen.SYNC -> BluetoothSyncScreen(viewModel)
                        }
                    }
                }
            }
        }
    }
}
